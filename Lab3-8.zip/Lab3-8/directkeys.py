import pyautogui
import time

for i in list(range(4))[::-1]:
    print(i+1)
    time.sleep(1)

print('accelerate')
pyautogui.keyDown('up')
time.sleep(5)
pyautogui.keyUp('up')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1)
pyautogui.keyUp('right')
