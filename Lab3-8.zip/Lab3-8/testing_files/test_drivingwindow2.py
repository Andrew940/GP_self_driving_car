import numpy as np
import cv2
import time

from get_screen_inputs import capture_drivingwindow
from sld_gp import param, process_image

def main():

    while True:

        drivingwindow = capture_drivingwindow(0,100,640,245)

        edges_image, lines_image, slope = process_image(drivingwindow)

        if (slope > -3.0 and slope < 3.5):
    
            if(slope > 1.2 and slope < 3.5):
                print("going straight")

            if (slope < -1.5 and slope > -3.0):
                print('turning right')

            if (slope > 0.7 and slope < 1.5):
                print('turning left')
            

##        else:
##            print(slope)

        
        #cv2.imshow('driving window',drivingwindow)
        cv2.imshow('edges',edges_image)
        cv2.imshow('lines',lines_image)

        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

main()




