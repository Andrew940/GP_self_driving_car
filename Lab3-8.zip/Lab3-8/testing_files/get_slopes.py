import numpy as np
import cv2
import time

from get_screen_inputs import capture_drivingwindow
from sld_gp import param, process_image

if __name__ == '__main__':

    font_type = cv2.FONT_HERSHEY_SIMPLEX
    font_size = 1
    GREEN = (0,255,0)    
    

    while True:

        drivingwindow = capture_drivingwindow(0,100,640,245)
        edges_image, lines_image, slope = process_image(drivingwindow)

        img = np.zeros((128,128,3), np.uint8)
        cv2.putText(img, "Direction", (10,30), font_type, font_size, GREEN)
   

        if (slope > -3.0 and slope < 3.5):
    
            if(slope > 1.2 and slope < 3.5):
                print('going straight')
                cv2.putText(img,"Straight", (10,60), font_type, font_size, GREEN)


            elif (slope < -1.5 and slope > -3.0):
                print('turning right')
                cv2.putText(img,"Right", (10,60), font_type, font_size, GREEN)


            elif (slope > 0.7 and slope < 1.5):
                print('turning left')
                cv2.putText(img,"Left", (10,60), font_type, font_size, GREEN)


        
        #cv2.imshow('driving window',drivingwindow)
        cv2.imshow('edges',edges_image)
        cv2.imshow('lines',lines_image)
        cv2.imshow('dashboard',img)

        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()




