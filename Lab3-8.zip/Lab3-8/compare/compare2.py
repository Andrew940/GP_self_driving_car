from skimage.measure import compare_ssim
import cv2
import numpy as np

def compare2images(imageA,imageB):
    
    s = compare_ssim(imageA, imageB)
    return s


if __name__ == '__main__':

    original = cv2.imread("images/jp_gates_original.png")
    contrast = cv2.imread("images/jp_gates_contrast.png")
    shopped = cv2.imread("images/jp_gates_photoshopped.png")

    # convert the images to grayscale
    original = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    contrast = cv2.cvtColor(contrast, cv2.COLOR_BGR2GRAY)
    shopped = cv2.cvtColor(shopped, cv2.COLOR_BGR2GRAY)

    s = compare2images(original,shopped)
    print(s)
