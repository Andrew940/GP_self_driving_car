import numpy as np
import cv2
import time

from PIL import Image
import pytesseract
from pytesseract import image_to_string

from grabscreen.grabscreen import grab_screen
from get_screen_inputs import*


pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract'

def read_speedometer(img):

    #Resize image 3x scale and convert to gray scale        
    scale_factor = 3
    num_value = None
    
    height, width = img.shape[:2]
    res_img = cv2.resize(img,(scale_factor*width, scale_factor*height), interpolation = cv2.INTER_CUBIC)
    res_img = cv2.cvtColor(res_img, cv2.COLOR_BGR2GRAY)

    #convert to PIL image and call pytesseract image_to_string function to OCR the given image
    conv_img = Image.fromarray(res_img)
    text = image_to_string(conv_img, config='outputbase digits')

    #Remove spaces and replace D for 0s
    text = text.replace(" ", "")
    text = text.replace("D","0")

    try:

        num_value = int(text)

    except Exception as e:
        pass

    
    return num_value



if __name__ == '__main__':

    font_type = cv2.FONT_HERSHEY_SIMPLEX
    font_size = 1
    GREEN = (0,255,0)    
    
    while True:

        img = np.zeros((128,128,3), np.uint8)
        speedometer = capture_speedometer()

        cv2.putText(img, "Speed", (10,30), font_type, font_size, GREEN)


        #Call the conversion functions
        msg = read_speedometer(speedometer)
        if(msg != None):
            print(msg)

            cv2.putText(img,str(msg), (10,60), font_type, font_size, GREEN)

        
        cv2.imshow('speedometer',speedometer)
        cv2.imshow('dashboard',img)


        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
            break
       

