import numpy as np
import cv2
import time

from PIL import Image
import pytesseract
from pytesseract import image_to_string

from utils.grabscreen import grab_screen
from utils.get_screen_inputs import*
from utils.sld_gp import param, process_image

pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract'
font_type = cv2.FONT_HERSHEY_SIMPLEX
font_size = 1
GREEN = (0,255,0) 


def display_speedometer(speedometer_img, img):

    cv2.putText(img, "Speed", (10,30), font_type, font_size, GREEN)

    #Resize image 3x scale and convert to gray scale        
    scale_factor = 3
    num_value = None
    
    height, width = speedometer_img.shape[:2]
    res_img = cv2.resize(speedometer_img,(scale_factor*width, scale_factor*height), interpolation = cv2.INTER_CUBIC)
    res_img = cv2.cvtColor(res_img, cv2.COLOR_BGR2GRAY)

    #convert to PIL image and call pytesseract image_to_string function to OCR the given image
    conv_img = Image.fromarray(res_img)
    text = image_to_string(conv_img, config='outputbase digits')

    #Remove spaces and replace D for 0s
    text = text.replace(" ", "")
    text = text.replace("D","0")

    text = text[:3]

    try:
        num_value = int(text)

    except Exception as e:
        pass

    if(num_value != None):
            cv2.putText(img,str(num_value), (10,60), font_type, font_size, GREEN)


def display_direction(slope, img):

    cv2.putText(img, "Direction", (130,30), font_type, font_size, GREEN)

    if (slope > -3.0 and slope < 3.5 and slope != None):

        #Going straight
        if(slope > 1.2 and slope < 3.5):
            cv2.putText(img,"Straight", (130,60), font_type, font_size, GREEN)

        #Left turns
        elif (slope > 0 and slope < 1.2):
            cv2.putText(img,"Left", (130,60), font_type, font_size, GREEN)

        #Right turns
        else:
            cv2.putText(img,"Right", (130,60), font_type, font_size, GREEN)

def capture_inputs():
    
    #Read inputs from the images speed and direction
    speedometer = capture_speedometer()

    #Read driving window, capture slope
    drivingwindow = capture_drivingwindow(0,100,640,245)
    edges_image, lines_image, slope = process_image(drivingwindow)
    overlap_img = cv2.addWeighted(drivingwindow, 0.2, lines_image, 0.8, 0.0)

    #Read map
    map_img = capture_map()

    return overlap_img, map_img, speedometer, slope

def display_images(overlap_img, map_img, img):

    #y1:y2 x1:x2
    # to check shape print(overlap_img.shape)
    
    #ovelap_img.shape is 146 x 641
    img[80:226, 0:641] = overlap_img
    #overlap map_img 74x171
    img[10:84, 400:571] = map_img
    

def run_dashboard():

    img = np.zeros((300,650,3), np.uint8)

    overlap_img, map_img, speedometer, slope = capture_inputs()
    display_images(overlap_img, map_img, img)

    #Process the slope and speedometer and show value
    display_direction(slope, img)
    display_speedometer(speedometer, img)
    
    cv2.imshow('dashboard',img)


if __name__ == '__main__':

    while True:
        
        run_dashboard()

        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()
            
            


