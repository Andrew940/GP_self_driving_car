import numpy as np
import cv2
import time
#from get_screen_inputs import capture_drivingwindow

from PIL import Image
import pytesseract
from pytesseract import image_to_string

from grabscreen.grabscreen import grab_screen
from get_screen_inputs import*
from sld_gp import param, process_image

pytesseract.pytesseract.tesseract_cmd = 'C:/Program Files (x86)/Tesseract-OCR/tesseract'

def display_speedometer(speedometer_img, img):

    #Resize image 3x scale and convert to gray scale        
    scale_factor = 3
    num_value = None
    
    height, width = speedometer_img.shape[:2]
    res_img = cv2.resize(speedometer_img,(scale_factor*width, scale_factor*height), interpolation = cv2.INTER_CUBIC)
    res_img = cv2.cvtColor(res_img, cv2.COLOR_BGR2GRAY)

    #convert to PIL image and call pytesseract image_to_string function to OCR the given image
    conv_img = Image.fromarray(res_img)
    text = image_to_string(conv_img, config='outputbase digits')

    #Remove spaces and replace D for 0s
    text = text.replace(" ", "")
    text = text.replace("D","0")

    text = text[:3]

    try:

        num_value = int(text)

    except Exception as e:
        pass

    if(num_value != None):
            cv2.putText(img,str(num_value), (10,60), font_type, font_size, GREEN)


def display_direction(slope, img):

    if (slope > -3.0 and slope < 3.5 and slope != None):

        if(slope > 1.2 and slope < 3.5):
            #print('going straight')
            cv2.putText(img,"Straight", (130,60), font_type, font_size, GREEN)


        elif (slope > 0 and slope < 1.2):
            #print('turning left')
            cv2.putText(img,"Left", (130,60), font_type, font_size, GREEN)

        #elif (slope < -1.5 and slope > -3.0):
        else:
            #print('turning right')
            cv2.putText(img,"Right", (130,60), font_type, font_size, GREEN)




if __name__ == '__main__':

    font_type = cv2.FONT_HERSHEY_SIMPLEX
    font_size = 1
    GREEN = (0,255,0)    
    
    while True:

        img = np.zeros((300,650,3), np.uint8)

        #Read inputs from the images speed and direction
        speedometer = capture_speedometer()

        drivingwindow = capture_drivingwindow(0,100,640,245)
        edges_image, lines_image, slope = process_image(drivingwindow)
        overlap_img = cv2.addWeighted(drivingwindow, 0.2, lines_image, 0.8, 0.0)

        #ovelap_img.shape is 146 x 641
        img[80:226, 0:641] = overlap_img

              
        #Show in dashboard speed and direction
        cv2.putText(img, "Speed", (10,30), font_type, font_size, GREEN)
        cv2.putText(img, "Direction", (130,30), font_type, font_size, GREEN)

        #Process the slope and speedometer and show value
        display_direction(slope, img)
        display_speedometer(speedometer, img)
        
        
        #cv2.imshow('overlap',overlap_img)    
        #cv2.imshow('edges',edges_image)
        #cv2.imshow('lines',lines_image)  
        #cv2.imshow('speedometer',speedometer)
        cv2.imshow('dashboard',img)


        if cv2.waitKey(25) & 0xFF == ord('q'):
            cv2.destroyAllWindows()
            break


