from scipy.misc import imread
from sklearn.externals import joblib

import random as rand
import numpy as np 
import cv2
import glob
import time

import matplotlib.pyplot as plt

from helpers import convert, show_images, put_boxes, box_boundaries
from featuresourcer import FeatureSourcer
from binaryclassifier import BinaryClassifier
from slider import Slider
from heatmap import HeatMap

#Settings

svc = joblib.load('svc2.pkl')
scaler = joblib.load('scaler2.pkl')

sourcer_params = {
  'color_model': 'yuv',                # hls, hsv, yuv, ycrcb
  'bounding_box_size': 64,             #
  'number_of_orientations': 11,        # 6 - 12
  'pixels_per_cell': 16,               # 8, 16
  'cells_per_block': 2,                # 1, 2
  'do_transform_sqrt': True
}

cls = BinaryClassifier(svc, scaler)
src = FeatureSourcer(sourcer_params, imread("vehicles/KITTI_extracted/5364.png"))
slider = Slider(sourcer = src, classifier = cls, increment = 8)

frame1 = imread("test1.jpg")
frame2 = imread("test2.jpg")
frame3 = imread("test3.jpg")
frame4 = imread("test4.jpg")
frame5 = imread("test5.jpg")
frame6 = imread("test6.jpg")

window_sizes = 64, 80, 120, 150
window_positions = 360, 410, 390, 380

heatmap = HeatMap(frame = frame1, thresh = 6, memory = 4)

#Functions

def heatmap_test(this_frame, this_heatmap, ws, wp):
    this_heatmap.reset()

    for sz, pos in zip(ws, wp):
        bounding_boxes = slider.locate(frame = this_frame, window_size = sz, window_position = pos)
        this_heatmap.update(bounding_boxes)

    this_heatmap.show(this_frame)


def main():

    
    heatmap_test(frame1, heatmap, window_sizes, window_positions)

    plt.show()


main()


  
