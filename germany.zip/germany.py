import pyautogui
import time

for i in list(range(4))[::-1]:
    print(i+1)
    time.sleep(1)

#McLaren
print('accelerate')
pyautogui.keyDown('up')
time.sleep(13.5)
pyautogui.keyUp('up')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1.20)
pyautogui.keyUp('right')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(16)
pyautogui.keyUp('up')

print('slowing down')
pyautogui.keyDown('down')
time.sleep(0.5)
pyautogui.keyUp('down')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1.5)
pyautogui.keyUp('right')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(0.7)
pyautogui.keyUp('up')

print('turning left')
pyautogui.keyDown('left')
time.sleep(1)
pyautogui.keyUp('left')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(4)
pyautogui.keyUp('up')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1)
pyautogui.keyUp('right')

print('turning left')
pyautogui.keyDown('left')
time.sleep(0.1)
pyautogui.keyUp('left')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(12)
pyautogui.keyUp('up')

print('slowing down')
pyautogui.keyDown('down')
time.sleep(0.8)
pyautogui.keyUp('down')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1.5)
pyautogui.keyUp('right')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(2.5)
pyautogui.keyUp('up')

print('turning left')
pyautogui.keyDown('left')
time.sleep(0.05)
pyautogui.keyUp('left')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(0.2)
pyautogui.keyUp('up')

print('turning right')
pyautogui.keyDown('right')
time.sleep(1.25)
pyautogui.keyUp('right')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(1)
pyautogui.keyUp('up')

print('turning left')
pyautogui.keyDown('left')
time.sleep(0.2)
pyautogui.keyUp('left')

print('accelerate')
pyautogui.keyDown('up')
time.sleep(11.5)
pyautogui.keyUp('up')

print('slowing down')
pyautogui.keyDown('down')
time.sleep(1.5)
pyautogui.keyUp('down')

print('turning left')
pyautogui.keyDown('left')
time.sleep(0.8)
pyautogui.keyUp('left')


